import java.io.*;
import java.net.*;

public class ChatClient {
    public static void main(String[] args) {
        try {
            // Create a socket to connect to the server
            Socket socket = new Socket("localhost", 9098);
            // Set up input and output streams for communication
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));
            String userInput;

            // Create a thread to receive and display messages from the server
            ReceiveMessageRunnable receiveMessageRunnable = new ReceiveMessageRunnable(input, socket);
            Thread receiveThread = new Thread(receiveMessageRunnable);
            receiveThread.start();

            while ((userInput = consoleInput.readLine()) != null && receiveThread.isAlive()) {
      
                // Send user input to the server
                if (userInput.equalsIgnoreCase("exit")) {
                    output.println(userInput);
                    break;
                }

                // Send user input to the server
                output.println(userInput);
                output.flush();
            }

        } catch (IOException e) {
            System.out.println("The server is currently offline");
        }
    }
}

// ReceiveMessageRunnable class handles receiving and displaying messages from the server
class ReceiveMessageRunnable implements Runnable {
    private BufferedReader input;
    private Socket socket;

    public ReceiveMessageRunnable(BufferedReader input, Socket socket) {
        this.input = input;
        this.socket = socket;
    }

    public void run() {
        String message;
        try {
            while ((message = input.readLine()) != null) {
                // Display received messages from the server
                System.out.println(message);
            }
            socket.close();
        } catch (IOException e) {
            System.out.println("The server has been stopped");
        }
    }
}
