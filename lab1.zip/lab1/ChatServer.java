import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class ChatServer {
    private ServerSocket serverSocket;
    List<ClientHandler> clients = new ArrayList<>();

    public ChatServer(int port) {
        try {
            serverSocket = new ServerSocket(port);
            System.out.println("Server is running on port " + port);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void start() {
        while (true) {
            try {
                Socket clientSocket = serverSocket.accept();
                // Create a new ClientHandler for each connected client
                ClientHandler clientHandler = new ClientHandler(clientSocket, this);
                clients.add(clientHandler);
                // Start a new thread to handle the client
                Thread thread = new Thread(clientHandler);
                thread.start();
                System.out.print("Client Address: " + clientSocket.getInetAddress());
                System.out.println(" Client port: " + clientSocket.getPort());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        // Create a ChatServer instance and start the server
        ChatServer server = new ChatServer(9098);
        server.start();
    }
}

public class ClientHandler implements Runnable {
    private Socket clientSocket;
    private ChatServer server;
    private PrintWriter out;
    private BufferedReader in;

    public ClientHandler(Socket socket, ChatServer server) {
        this.clientSocket = socket;
        this.server = server;
    }

    public void run() {
        String clientPort = "[Client port: " + clientSocket.getPort()+"] ";
        String exit_message = clientPort + "has left the chat";
        String message;
        try {
            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            while ((message = in.readLine()) != null) {
                    if(message.equalsIgnoreCase("exit")) {
                    this.out.println("You has left the chat");
                    break;
                }
                // Broadcast the message to all clients except the sender
                broadcastMessage(clientPort + message, this);
            }

            // Notify clients when this client leaves the chat
            broadcastMessage(exit_message, this);
        } catch (IOException e) {
            // Notify clients if there's an issue with this client
            broadcastMessage(exit_message, this);
        } finally {
            try {
                // Remove this client from the list and close the socket
                server.clients.remove(this);
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void broadcastMessage(String message, ClientHandler sender) {
        // Broadcast the message to all clients except the sender
        for (ClientHandler client : server.clients) {
            if (client != sender) {
                client.out.println(message);
            }
        }
    }
}
