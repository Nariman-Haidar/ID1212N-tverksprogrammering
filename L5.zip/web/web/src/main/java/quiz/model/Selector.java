package quiz.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "selector")
public class Selector {
    @Id
    @ManyToOne
    @JoinColumn(name = "quiz_id")
    private Quizzes quiz;

    @Id
    @ManyToOne
    @JoinColumn(name = "question_id")
    private Questions question;
}

