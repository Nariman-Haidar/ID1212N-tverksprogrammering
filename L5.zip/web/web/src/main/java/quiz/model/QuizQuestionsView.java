package quiz.model;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.Immutable;

@Entity
@Immutable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QuizQuestionsView {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "question_id")
    private Long questionId;

    @Column(name = "quiz_id")
    private Long quizId;

    private String text;
    private String options;
    private String answer;
}

