package quiz.controller;

import jakarta.mail.MessagingException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import quiz.DTO.QuestionDTO;
import quiz.DTO.QuizDTO;
import quiz.DTO.ResultDTO;
import quiz.DTO.UserDTO;
import quiz.model.Results;
import quiz.service.QuestionService;
import quiz.service.QuizzesService;
import quiz.service.ResultsService;
import quiz.service.UsersService;

import java.io.UnsupportedEncodingException;
import java.util.*;
import java.util.stream.Collectors;

@Controller
public class ResultsController {
    private final QuestionService questionService;
    private final ResultsService resultsService;

    private final QuizzesService quizService;

    private final EmailService emailService;

    public ResultsController(ResultsService resultsService, QuizzesService quizService, QuestionService questionService, EmailService emailService) {
        this.resultsService = resultsService;
        this.quizService = quizService;
        this.questionService = questionService;
        this.emailService = emailService;
    }


    @PostMapping("/submitAnswers")
    public String showQuizResults(@RequestParam("quizId") Long quizId,
                                  @RequestParam("userSelections") String userSelections,
                                  @SessionAttribute("user") UserDTO userDTO,
                                  Model model) {


        List<QuestionDTO> questions = questionService.getQuestionsByQuizId(quizId);
        Map<Long, List<String>> correctAnswersMap = getCorrectAnswersMap(questions);
        Map<Long, String> userSelectionsMap = parseUserSelections(userSelections);
        int score = calculateScore(userSelectionsMap, correctAnswersMap);

        QuizDTO quizDTO = quizService.getQuizById(quizId);

        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setUserDTO(userDTO);
        resultDTO.setQuizDTO(quizDTO);
        resultDTO.setScore(score);


        resultsService.saveResult(resultDTO);


        try {
            String emailSubject = "Quiz Result";
           String emailBody = "Dear " + userDTO.getUsername() + ",\n\nYour score for the quiz \"" +
                   quizDTO.getSubject() + "\" is: " + score;

            emailService.sendEmail(userDTO.getUsername() , emailSubject, emailBody);
        } catch (MessagingException e) {

            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }

        List<ResultDTO> scores = resultsService.getScoresByUserAndQuiz(userDTO.getId(), quizDTO.getId());
        model.addAttribute("results", scores);
        return "scores";

    }

    private static Map<Long, String> parseUserSelections(String userSelections) {
        Map<Long, String> userAnswers = new HashMap<>();
        // Remove curly braces and double quotes from the input string
        userSelections = userSelections.replaceAll("[{}\"]", "");
        String[] answers = userSelections.split(",");
        for (String answer : answers) {
            String[] parts = answer.split(":");
            Long question_id = Long.parseLong(parts[0]);
            userAnswers.put(question_id, parts[1]);
        }
        return userAnswers;
    }

    private Map<Long, List<String>> getCorrectAnswersMap(List<QuestionDTO> questions) {
        Map<Long, List<String>> correctAnswersMap = new HashMap<>();

        for (QuestionDTO question : questions) {

            String[] options = question.getOptions().split("/");
            String[] answers = question.getAnswer().split("/");
            List<String> list = new ArrayList<>();
            for (int i=0; i < answers.length; i++) {
                int answer = Integer.parseInt(answers[i]);
                if (answer > 0) {
                    list.add(options[i]);
                }
            }
            correctAnswersMap.put(question.getId(), list);
        }

        return correctAnswersMap;
    }

    private int calculateScore(Map<Long, String> userAnswers, Map<Long, List<String>> correctAnswers) {
        int score = 0;
        for (Map.Entry<Long, String> entry : userAnswers.entrySet()) {
            Long questionId = entry.getKey();
            String userAnswer = entry.getValue();
            List<String> correctAnswersOfOneQuestion = correctAnswers.get(questionId);
            for (String answer : correctAnswersOfOneQuestion){
            if (answer.equals(userAnswer)) {
               score++;
              }
            }
          }
        return score;
       }

   }
