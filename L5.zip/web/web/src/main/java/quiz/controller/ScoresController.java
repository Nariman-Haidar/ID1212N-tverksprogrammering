package quiz.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import quiz.DTO.UserDTO;
import quiz.service.QuizzesService;
import quiz.service.ResultsService;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.ui.Model;
import quiz.DTO.QuizDTO;
import quiz.DTO.ResultDTO;
import java.util.*;
@Controller
public class ScoresController {
    private final ResultsService resultsService;
    private final QuizzesService quizService;
    public ScoresController(ResultsService resultsService, QuizzesService quizService) {
        this.resultsService = resultsService;
        this.quizService = quizService;
    }

    @GetMapping("/scores")
    public String showScores(@RequestParam("quizId") Long quizId,
                             @SessionAttribute("user") UserDTO userDTO,
                             Model model) {

            QuizDTO quizDTO = quizService.getQuizById(quizId);
            model.addAttribute("quizDTO", quizDTO);

        List<ResultDTO> scores = resultsService.getScoresByUserAndQuiz(userDTO.getId(), quizDTO.getId());
        for (ResultDTO sco : scores) {
            System.out.println(sco);
        }

        model.addAttribute("results", scores);
        return "scores";
    }
}

