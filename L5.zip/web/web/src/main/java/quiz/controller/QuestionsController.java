package quiz.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import quiz.DTO.QuestionDTO;
import quiz.DTO.QuizDTO;
import quiz.service.QuestionService;
import quiz.service.QuizzesService;

import java.util.*;
import java.util.stream.Collectors;

@Controller
@SessionAttributes("quizDTO")
public class QuestionsController {

    private final QuestionService questionService;
    private final QuizzesService quizzesService;

    public QuestionsController(QuestionService questionService, QuizzesService quizzesService) {
        this.questionService = questionService;
        this.quizzesService = quizzesService;
    }

    @PostMapping("/questions")
    public String showAllQuestions(@RequestParam(name = "quizId", required = false) Long quizId, Model model) {
        List<QuestionDTO> allQuestions;

        if (quizId != null) {

            QuizDTO quizDTO = quizzesService.getQuizById(quizId);


            System.out.println("QuizDTO: " + quizDTO);


            allQuestions = questionService.getQuestionsByQuizId(quizId);
            model.addAttribute("quizDTO", quizDTO);


        } else {
            allQuestions = questionService.getAllQuestions();
        }


        List<List<String>> optionsList = allQuestions.stream()
                .map(question -> Arrays.asList(question.getOptions().split("/")))
                .collect(Collectors.toList());

        model.addAttribute("quizId", quizId);
        model.addAttribute("questions", allQuestions);
        model.addAttribute("optionsList", optionsList);

        return "questions";
    }
}

