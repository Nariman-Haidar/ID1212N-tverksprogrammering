package quiz.controller;

import org.springframework.ui.Model;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import quiz.DTO.UserDTO;
import quiz.service.UsersService;


import java.util.List;

@Controller
public class UsersController {

    private final UsersService usersService;

    public UsersController(UsersService usersService) {
        this.usersService = usersService;
    }

    @GetMapping("/users")
    public String listUsers(Model model) {
        List<UserDTO> users = usersService.findAllUsers();
        model.addAttribute("users", users);
        return "users";
    }
}

