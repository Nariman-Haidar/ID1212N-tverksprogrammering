package quiz.controller;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import quiz.DTO.QuizDTO;
import quiz.DTO.UserDTO;
import quiz.service.QuizzesService;
import quiz.service.UsersService;

import java.util.List;
import java.util.Optional;

@Controller
@SessionAttributes("user")
public class LoginController {

    private final UsersService usersService;
    private final QuizzesService quizzesService;


    private final MessageSource messageSource;


    public LoginController(UsersService usersService, QuizzesService quizzesService, MessageSource messageSource) {
        this.usersService = usersService;
        this.quizzesService = quizzesService;
        this.messageSource = messageSource;
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam String username, @RequestParam String password, Model model) {
        if (usersService.isValidLogin(username, password)) {
            Optional<UserDTO> userDTO = usersService.findUserByUsername(username);

            if (userDTO != null) {
                Long userId = userDTO.get().getId();
               // System.out.println("User ID: " + userId);
                model.addAttribute("user", userDTO.get());
            }
            return "redirect:/quizzes";
        } else {
            
            String errorMessage = messageSource.getMessage("login.error.message", null, LocaleContextHolder.getLocale());
            model.addAttribute("error", errorMessage);
            return "login";
        }
    }

    @GetMapping("/quizzes")
    public String showQuizzes(Model model) {

        List<QuizDTO> quizzes = quizzesService.getAllQuizzes();
        model.addAttribute("quizzes", quizzes);

        return "quizzes";
    }

}
