package quiz.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import quiz.model.Questions;

import java.util.List;

@Repository
public interface QuestionRepository extends JpaRepository<Questions, Long> {
    @Query("SELECT s.question FROM Selector s WHERE s.quiz.id = :quizId")
    List<Questions> findByQuizId(@Param("quizId") Long quizId);
}


