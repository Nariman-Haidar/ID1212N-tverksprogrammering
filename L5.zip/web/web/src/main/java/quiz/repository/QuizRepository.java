package quiz.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import quiz.model.Quizzes;

public interface QuizRepository extends JpaRepository<Quizzes, Long> {

}
