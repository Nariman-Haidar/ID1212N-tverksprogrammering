package quiz.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import quiz.model.Results;

import java.util.List;

public interface ResultsRepository extends JpaRepository<Results, Long> {
    List<Results> findByUserIdAndQuizId(Long userId, Long quizId);
}
