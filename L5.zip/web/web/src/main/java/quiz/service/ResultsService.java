package quiz.service;

import quiz.DTO.ResultDTO;


import java.util.List;

public interface ResultsService {
    void saveResult(ResultDTO resultDTO);
    List<ResultDTO> getScoresByUserAndQuiz(Long userId, Long quizId);
}
