package quiz.service;

import quiz.DTO.UserDTO;
import quiz.model.Users;

import java.util.List;
import java.util.Optional;

public interface UsersService {
    List<UserDTO> findAllUsers();

    boolean isValidLogin(String username, String password);
    Optional<UserDTO> findUserByUsername(String username);

}