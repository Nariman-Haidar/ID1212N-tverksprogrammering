package quiz.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import quiz.DTO.QuestionDTO;
import quiz.mapper.QuestionMapper;
import quiz.model.Questions;
import quiz.repository.QuestionRepository;
import quiz.service.QuestionService;
import quiz.mapper.QuestionMapper;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class QuestionServiceImpl implements QuestionService {

    private final QuestionRepository questionRepository;
    private final QuestionMapper questionMapper;

    public QuestionServiceImpl(QuestionRepository questionRepository, QuestionMapper questionMapper) {
        this.questionRepository = questionRepository;
        this.questionMapper = questionMapper;
    }

    @Override
    public List<QuestionDTO> getAllQuestions() {
        List<Questions> questions = questionRepository.findAll();
        return questions.stream()
                .map(QuestionMapper::mapToQuestionDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<QuestionDTO> getQuestionsByQuizId(Long quizId) {
        return questionRepository.findByQuizId(quizId).stream()
                .map(QuestionMapper::mapToQuestionDto)
                .collect(Collectors.toList());
    }
}
