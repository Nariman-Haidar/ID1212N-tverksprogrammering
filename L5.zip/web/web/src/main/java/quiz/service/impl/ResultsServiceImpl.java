package quiz.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import quiz.DTO.ResultDTO;
import quiz.mapper.ResultMapper;
import quiz.repository.ResultsRepository;
import quiz.model.Results;
import quiz.service.ResultsService;

import java.util.List;
import java.util.stream.Collectors;


@Service
public class ResultsServiceImpl implements ResultsService {

    private final ResultsRepository resultsRepository;

    @Autowired
    public ResultsServiceImpl(ResultsRepository resultsRepository) {
        this.resultsRepository = resultsRepository;
    }

    @Override
    public List<ResultDTO> getScoresByUserAndQuiz(Long userId, Long quizId) {
        List<Results> resultsList = resultsRepository.findByUserIdAndQuizId(userId, quizId);
        return resultsList.stream()
                .map(ResultMapper::mapToResultDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void saveResult(ResultDTO resultDTO) {

        Results results = ResultMapper.mapToResults(resultDTO);

        resultsRepository.save(results);
    }
}



