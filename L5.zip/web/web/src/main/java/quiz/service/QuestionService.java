package quiz.service;

import quiz.DTO.QuestionDTO;

import java.util.List;

public interface QuestionService {
    List<QuestionDTO> getQuestionsByQuizId(Long quizId);
    List<QuestionDTO> getAllQuestions();
}

