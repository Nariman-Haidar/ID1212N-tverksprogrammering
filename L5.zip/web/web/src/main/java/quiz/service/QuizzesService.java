package quiz.service;

import quiz.DTO.QuizDTO;

import java.util.List;

public interface QuizzesService {
    List<QuizDTO> getAllQuizzes();
    QuizDTO getQuizById(Long quizId);
}
