package quiz.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import quiz.DTO.QuizDTO;
import quiz.mapper.QuizMapper;
import quiz.model.Quizzes;
import quiz.repository.QuizRepository;
import quiz.service.QuizzesService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class QuizzesServiceImpl implements QuizzesService {

    private final QuizRepository quizRepository;

    @Autowired
    public QuizzesServiceImpl(QuizRepository quizRepository) {
        this.quizRepository = quizRepository;
    }

    @Override
    public List<QuizDTO> getAllQuizzes() {
        List<Quizzes> quizzes = quizRepository.findAll();
        return quizzes.stream()
                .map(QuizMapper::mapToQuizDTO)
                .collect(Collectors.toList());
    }
    @Override
    public QuizDTO getQuizById(Long quizId) {
        Optional<Quizzes> quizOptional = quizRepository.findById(quizId);
        return quizOptional.map(QuizMapper::mapToQuizDTO).orElse(null);
    }
}
