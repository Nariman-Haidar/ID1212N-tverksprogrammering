package quiz.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import quiz.DTO.UserDTO;
import quiz.mapper.UsersMapper;
import quiz.model.Users;
import quiz.repository.UsersRepository;
import quiz.service.UsersService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UsersServiceImpl implements UsersService {

    private final UsersRepository usersRepository;

    @Autowired
    public UsersServiceImpl(UsersRepository userRepository) {
        this.usersRepository = userRepository;
    }

    @Override
    public boolean isValidLogin(String username, String password) {
        Optional<Users> userOptional = usersRepository.findByUsername(username);
        return userOptional.map(user -> user.getPassword().equals(password)).orElse(false);
    }
    @Override
    public List<UserDTO> findAllUsers() {
        List<UserDTO> usersDTOList = usersRepository.findAll().stream()
                .map(UsersMapper::mapToUsersDto)
                .collect(Collectors.toList());
        return usersDTOList;
    }

        @Override
        public Optional<UserDTO> findUserByUsername(String username) {
            Optional<Users> userOptional = usersRepository.findByUsername(username);
            return userOptional.map(UsersMapper::mapToUsersDto);
        }
    }
