package quiz.mapper;


import quiz.DTO.UserDTO;
import quiz.model.Users;

public class UsersMapper {
    public static Users mapToUsers(UserDTO usersDto) {
        Users users = Users.builder()
                .id(usersDto.getId())
                .username(usersDto.getUsername())
                .password(usersDto.getPassword())
                .build();
        return users;
    }

    public static UserDTO mapToUsersDto(Users users) {
        UserDTO userDto = UserDTO.builder()
                .id(users.getId())
                .username(users.getUsername())
                .password(users.getPassword())
                .build();
        return userDto;
    }
}
