package quiz.mapper;

import org.springframework.stereotype.Component;
import quiz.DTO.QuestionDTO;
import quiz.model.Questions;
    @Component
    public class QuestionMapper {
        public static QuestionDTO mapToQuestionDto(Questions question) {
            QuestionDTO questionDTO = new QuestionDTO();
            questionDTO.setId(question.getId());
            questionDTO.setText(question.getText());
            questionDTO.setOptions(question.getOptions());
            questionDTO.setAnswer(question.getAnswer());
            return questionDTO;
        }
    }

