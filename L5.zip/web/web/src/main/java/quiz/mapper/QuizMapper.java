package quiz.mapper;

import quiz.DTO.QuizDTO;
import quiz.model.Quizzes;

public class QuizMapper {
    public static QuizDTO mapToQuizDTO(Quizzes quiz) {
        QuizDTO quizDTO = new QuizDTO();
        quizDTO.setId(quiz.getId());
        quizDTO.setSubject(quiz.getSubject());
        return quizDTO;
    }
}
