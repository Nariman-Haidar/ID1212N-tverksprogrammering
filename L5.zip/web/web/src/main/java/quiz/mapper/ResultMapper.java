package quiz.mapper;

import quiz.DTO.QuizDTO;
import quiz.DTO.ResultDTO;
import quiz.DTO.UserDTO;
import quiz.model.Quizzes;
import quiz.model.Results;

import quiz.model.Users;

public class ResultMapper {
    public static Results mapToResults(ResultDTO resultDTO) {
        Results results = new Results();


        Users user = new Users();
        user.setId(resultDTO.getUserDTO().getId());

        Quizzes quiz = new Quizzes();
        quiz.setId(resultDTO.getQuizDTO().getId());

        results.setUser(user);
        results.setQuiz(quiz);
        results.setScore(resultDTO.getScore());

        return results;
    }

    public static ResultDTO mapToResultDTO(Results results) {
        ResultDTO resultDTO = new ResultDTO();

        resultDTO.setId(results.getId());

        UserDTO userDTO = new UserDTO();
        userDTO.setId(results.getUser().getId());

        resultDTO.setUserDTO(userDTO);

        QuizDTO quizDTO = new QuizDTO();
        quizDTO.setId(results.getQuiz().getId());

        resultDTO.setQuizDTO(quizDTO);

        resultDTO.setScore(results.getScore());

        return resultDTO;
    }
}
