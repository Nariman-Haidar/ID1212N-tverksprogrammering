package quiz.DTO;

import lombok.Data;

@Data
public class QuestionDTO {
    private Long id;
    private String text;
    private String options;
    private String answer;
}

