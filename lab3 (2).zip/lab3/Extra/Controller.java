import java.io.*;
import java.util.*;

import javax.net.ssl.SSLSocket;

public class Controller implements Runnable{

        private SSLSocket socket;
        private Game game;
        private Map<String,  Game> map;

        public Controller(SSLSocket socket, Map<String, Game> sessionMap) {
            this.socket = socket;
            this.map = sessionMap;
        }
        
        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
                 String request = in.readLine();

                if (request == null || request.contains("favicon.ico")){
                    return;
                } 
                    
 
                String sessionId = extractSessionIdFromRequest(in);
        
                if (request.startsWith("GET")) {

                    if (!map.containsKey(sessionId)) {
                        this.game = new Game();
                        sessionId = this.game.getSessionId();
                       // System.out.println("sessionId "+ sessionId +"  ### this.game " + this.game);
                         map.put(sessionId, this.game);
                    }

                    handleHttpRequest(out, in, request, sessionId,  map.get(sessionId));
                }

                socket.close();
            } catch (IOException e) {
               System.err.println(e);
            }
        }
    

        private void handleHttpRequest(PrintWriter out, BufferedReader in, String request, String sessionId, Game game) {
            try {
              // System.out.println("request = " + request + " " + "sessionId = " + sessionId + " SecretNumber = " + game.getSecretNumber());
        
                if (request != null && request.startsWith("GET")) {
                    String guessParameter = extractGuessParameter(request);
                    if (guessParameter != null) {
                        try {
                            Integer guess = Integer.parseInt(guessParameter);
                            int guessStatus = game.checkGuess(guess);
                            //System.out.println(guessStatus);
                            View.generateGameView(out, sessionId, guessStatus, game.numberOfGuesses());
                            if (guessStatus == 0)
                                this.map.remove(sessionId);
                        } catch (NumberFormatException e) {
                            View.generateGameView(out, sessionId, -2, game.numberOfGuesses());
                        }
                    } else {
                        View.generateFormView(out, sessionId);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
 

            private  static String extractGuessParameter(String requestURL) {
            String[] parts = requestURL.split("\\?"); 
            if (parts.length > 1) {
                String query = parts[1];
                String[] params = query.split("&");
                for (String param : params) {
                    String[] keyValue = param.split("=");
                    if (keyValue.length == 2 && keyValue[0].equals("guess")) {
                        String str = keyValue[1].split(" ")[0];
                        if(str.length()==0) 
                         return null;
                        return str;
                    }
                }
            }
            return null;
        }
        
        private static String extractSessionIdFromRequest(BufferedReader in){
            try {
                String line;
                while ((line = in.readLine()) != null && !line.isEmpty()) {
                 //  System.out.println(line);
                    if (line.startsWith("Cookie:")) {
                        String[] cookieValues = line.substring("Cookie:".length()).trim().split(";");
                        for (String cookieValue : cookieValues) {
                            String[] parts = cookieValue.trim().split("=");
                            if (parts.length == 2 && parts[0].trim().equals("SESSID")) {
                                return parts[1].trim();
                            }
                        }
                    }
                }
              } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
     }
    
 }
