 import java.util.Random;
 import java.util.UUID;

public class Game {
    private int secretNumber;
    private int numberOfGuesses;
    private String sessionId;
    Random rand = new Random();

    public Game() {
        this.secretNumber = rand.nextInt(100) + 1;
        this.numberOfGuesses = 0;
        this.sessionId = UUID.randomUUID().toString();
    }

   public int numberOfGuesses(){
    return numberOfGuesses;
    }

    public int checkGuess(int guess) {
        numberOfGuesses++;
        if (guess < secretNumber) {
            return -1; 
        } else if (guess > secretNumber) {
            return 1; 
        } else {
            return 0;
        }
    }

    public String getSessionId() {
        return this.sessionId;
    }

     public int getSecretNumber() {
        return this.secretNumber;
    }
}