import java.io.*;

class View {
    public static void generateGameView(PrintWriter out, String sessionId, int guessStatus, int numberOfGuesses) {
         String str = "";
        if (guessStatus == -1) {
            str = "<p>Guess is too low.</p>";
        } else if (guessStatus == 1) {
            str = "<p>Guess is too high.</p>";
        } else if (guessStatus == 0) {
           str = "<h3>Congratulations! You guessed it right this time.</h3>";
        }
       else if (guessStatus == -2){
           str = "<h4>Please enter a valid number.</h4>";
        } 
        out.println("HTTP/1.1 200 OK");
        out.println("Content-Type: text/html; charset=UTF-8");
        out.println("Set-Cookie: SESSID=" + sessionId);
        out.println();
        out.println("<html><body>");
        out.println("<h1>Guess the Number Game</h1>");
        out.println("<p>Guess a number between 1 and 100.</p>");
        out.println("<form method='GET' action=''>");
        out.println("<input type='text' id='guess' name='guess'>");
        out.println("<input type='submit' value='Submit'>");
        out.println("</form>");
        out.println(str);
        out.println("<p>You have made " + numberOfGuesses + " guesses.</p>");
        out.println("</body></html>");
        out.flush();
    }

    public static void generateFormView(PrintWriter out, String sessionId) {
        out.println("HTTP/1.1 200 OK");
        out.println("Content-Type: text/html; charset=UTF-8");
        out.println("Set-Cookie: SESSID=" + sessionId);
        out.println();
        out.println("<html><body>");
        out.println("<h1>Guess the Number Game</h1>");
        out.println("<p>Guess a number between 1 and 100.</p>");
        out.println("<form method='GET' action='/'>");
        out.println("<input type='text' id='guess' name='guess'>");
        out.println("<input type='submit' value='Submit'>");
        out.println("<p>Don't forget to write a number</p>");
        out.println("</form>");
        out.println("</body></html>");
        out.flush();
    }
}
