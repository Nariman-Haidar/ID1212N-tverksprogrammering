import java.io.*;
import javax.net.ssl.*;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Map;

public class StartUp {

    private static final int PORT = 8443;
    private static final String KEYSTORE_PATH = "C:\\Users\\ps\\OneDrive\\Desktop\\Extra\\lab3.pfx";
    private static final String KEYSTORE_PASSWORD = "qwerty";
    private static final String[] ENABLED_CIPHER_SUITES = {"TLS_RSA_WITH_AES_128_CBC_SHA"};

    public static void main(String[] args) {
        SSLServerSocketFactory ssf;
        Map<String, Game> sessionMap = new HashMap<>();

        try {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            try (InputStream is = new FileInputStream(new File(KEYSTORE_PATH))) {
                ks.load(is, KEYSTORE_PASSWORD.toCharArray());
            }

            SSLContext ctx = SSLContext.getInstance("TLS");
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(ks, KEYSTORE_PASSWORD.toCharArray());

            ctx.init(kmf.getKeyManagers(), null, null);
            ssf = ctx.getServerSocketFactory();

            SSLServerSocket ss = (SSLServerSocket) ssf.createServerSocket(PORT);
            ss.setEnabledCipherSuites(ENABLED_CIPHER_SUITES);

            System.out.println("Server listening on port " + PORT);

            while (true) {
                SSLSocket clientSocket = (SSLSocket) ss.accept();
                Thread thread = new Thread(new Controller(clientSocket, sessionMap));
                thread.start();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
