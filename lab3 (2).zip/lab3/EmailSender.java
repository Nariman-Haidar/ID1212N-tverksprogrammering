import javax.net.ssl.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Base64;
import java.net.Socket;

public class EmailSender {
    private static final String SMTP_SERVER = "smtp.kth.se";
    private static final int SMTP_PORT = 587;
    
    public static void main(String[] args) {
        // Set the username and password
        String username = Credentials.getUsername();
        String password = Credentials.getPassword();

        // Set the recipient email address
        String toAddress = Credentials.getUsername();

        // Send the email
        sendEmail(username, password, toAddress);
    }

    public static void sendEmail(String username, String password, String toAddress) {
        // Set the email subject and content
        String subject = "Test Email";
        String content = "hello world";
        SSLSocket ssl_Socket = null;
        BufferedReader ssl_In = null;
        PrintWriter ssl_Out = null;

        try {
            // Connect to the SMTP server
            Socket socket = new Socket(SMTP_SERVER, SMTP_PORT);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            // Read the initial server response
            readResponse(in);
           
            // Send STARTTLS command
             sendCommand("STARTTLS", out);  
             readResponse(in);

            // Create an SSLSocketFactory
            SSLSocketFactory sslSocketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            
            // Upgrade to a secure connection
            ssl_Socket = (SSLSocket) sslSocketFactory.createSocket(socket, SMTP_SERVER, SMTP_PORT, true);
            ssl_In = new BufferedReader(new InputStreamReader(ssl_Socket.getInputStream()));
            ssl_Out = new PrintWriter(ssl_Socket.getOutputStream(), true);
 
             sendCommand("EHLO smtp.kth.se", ssl_Out); 
             readResponse(ssl_In);
             
             sendCommand("AUTH LOGIN", ssl_Out);  
             readResponse(ssl_In);

             sendCommand(encodeBase64(username), ssl_Out);  
             readResponse(ssl_In);

            sendCommand(encodeBase64(password), ssl_Out);  
            readResponse(ssl_In);
 
             sendCommand("MAIL FROM: <" + username + "@kth.se>", ssl_Out);  
             readResponse(ssl_In);

             sendCommand("RCPT TO: <" + toAddress + "@kth.se>", ssl_Out);  
             readResponse(ssl_In);

            sendCommand("DATA", ssl_Out);  
            readResponse(ssl_In);

            sendCommand(subject, ssl_Out);  
            sendCommand(content, ssl_Out);  

            sendCommand(".", ssl_Out);  
            
            readResponse(ssl_In);
            sendCommand("QUIT", ssl_Out);  
            readResponse(ssl_In);

            System.out.println("Email sent successfully.");

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error sending email: " + e.getMessage());
        } finally {
            try {
                if (ssl_Socket != null) {
                    ssl_Socket.close();
                }
                if (ssl_In != null) {
                    ssl_In.close();
                }
                if (ssl_In != null) {
                    ssl_In.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    private static void readResponse(BufferedReader reader) throws IOException {
        String line;
    
        while ((line = reader.readLine()) != null) {
            if (line.contains("334")) {
                String n = line.split("\\s")[0];
                String encodedValue = line.split("\\s")[1];
                System.out.println("Server: "+ n +" "+ decodeBase64(encodedValue));
            } else {
                System.out.println("Server: " + line);
            }
    
            // Check for the end of a multi-line response
            if (line.matches("\\d{2,} .*")) {
                break;
            }
        }
         System.out.println("--------------------------------------------");
    }


private static void sendCommand(String command, PrintWriter out) {
    System.out.println("Client: " + command);
    out.println(command);
    out.flush();
}

public static String decodeBase64(String encodedString) {
    byte[] decodedBytes = Base64.getDecoder().decode(encodedString);
    return new String(decodedBytes);
}

public static String encodeBase64(String input) {
    return Base64.getEncoder().encodeToString(input.getBytes());
}
}
