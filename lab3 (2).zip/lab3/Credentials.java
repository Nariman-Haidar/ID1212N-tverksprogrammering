
public class Credentials {
    private static final String USERNAME = "";
    private static final String PASSWORD = "";

        public static String getUsername() {
        return USERNAME;
    }

    public static String getPassword() {
       return PASSWORD;
    }
}

