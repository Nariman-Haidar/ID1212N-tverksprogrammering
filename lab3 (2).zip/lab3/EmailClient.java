import javax.net.ssl.*;
import java.util.*;
import java.io.*;

public class EmailClient {
    private static int tagCounter = 1;
    private static int EXIST = 1;

    public static void main(String[] args) {
        String username = Credentials.getUsername();
        String password = Credentials.getPassword();

        connectToIMAPServer(username, password);
    }

    private static void connectToIMAPServer(String username, String password) {
        SSLSocket sslSocket = null;
        BufferedReader imapReader = null;
        PrintWriter imapWriter = null;

        try {
            // SSL connection to IMAP server
            SSLSocketFactory sslSocketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            sslSocket = (SSLSocket) sslSocketFactory.createSocket("webmail.kth.se", 993);

            imapReader = new BufferedReader(new InputStreamReader(sslSocket.getInputStream()));
            imapWriter = new PrintWriter(sslSocket.getOutputStream(), true);

            readEmailContent(imapReader);

            // Authenticate with username and password
            sendIMAPCommand(imapWriter, "LOGIN " + username +" "+password);
            readEmailContent(imapReader);
  
            // Select the INBOX
           sendIMAPCommand(imapWriter,"SELECT INBOX");
           readEmailContent(imapReader);
 
            // Fetch the random email
              fetchRandomEmail(imapWriter,EXIST);

            // Fetch the newest email
            //sendIMAPCommand(imapWriter,"FETCH " + (EXIST) + " BODY[TEXT]<0.1024>");

            readEmailContent(imapReader);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (sslSocket != null) {
                    sslSocket.close();
                }
                if (imapReader != null) {
                    imapReader.close();
                }
                if (imapWriter != null) {
                    imapWriter.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

 

    private static void readEmailContent(BufferedReader imapReader) throws IOException {
        String imapResponse;
        while ((imapResponse = imapReader.readLine()) != null) {
            System.out.println("Server: " + imapResponse);
              if (imapResponse.contains("EXIST")){  
               EXIST = Integer.parseInt(imapResponse.split("\\s")[1]);              
              }
            // the condition based on the expected end of email content
            if (imapResponse.contains("service is ready") || 
                imapResponse.contains("completed") || 
                imapResponse.contains("BAD Command") ||
                imapResponse.contains("A" + tagCounter)
                ) {
                break;
            }
        }
        System.out.println("#################################");
    }

    private static void sendIMAPCommand(PrintWriter imapWriter,  String command) throws IOException {
         String tag = generateTag();
        if (command.contains("LOGIN")) {
         System.out.println("Client: " + tag + " LOGIN username password");
        }else{
         System.out.println("Client: " + tag + " " + command);
        }

        imapWriter.println(tag + " " + command);
        imapWriter.flush();
    }

    private static void fetchRandomEmail(PrintWriter imapWriter, int maxEmailNumber) throws IOException {
        int randomEmailNumber = new Random().nextInt(maxEmailNumber) + 1;
        String fetchCommand = "FETCH " + randomEmailNumber + " BODY[TEXT]<0.1024>";
        sendIMAPCommand(imapWriter,  fetchCommand);
    }

    private static String generateTag() {
        //a counter to create a unique tag
        return "A" + tagCounter++;
    }
}

