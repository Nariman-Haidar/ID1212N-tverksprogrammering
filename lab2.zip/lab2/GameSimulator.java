import java.util.*;
import java.util.stream.Collectors;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
 

public class GameSimulator {
    private static int N = 100;
    
    public static void main(String[] args) throws Exception {
        int[] ArrayOfSum = new int[N];

        for (int i = 0; i < N; i++) {
            int min = 1, max = 100, nrOfGuesses = 0;
            String initialCookie = "";  // Initialize the initialCookie

            while (true) {
                int number = (min + max) / 2;
                nrOfGuesses++;

                String  guessUrl = "http://localhost:8081/?guess=" + number;
                
                HttpResponse<String> response = sendRequestWithCookie(guessUrl, initialCookie);
                String guessResponse =  response.body();
                // Extract the Set-Cookie header and update the initialCookie
                String setCookie = extractSetCookie(response);
               // System.out.println("Set-Cookie: " + setCookie);
                if (!setCookie.isEmpty()) {
                    initialCookie = setCookie;
                }

                if (guessResponse.contains("high")) {
                    max = number - 1;
                } else if (guessResponse.contains("low")) {
                    min = number + 1;
                } else if (guessResponse.contains("Congratulations!")) {
                    System.out.println("Congratulations! The number is: " + number);
                    ArrayOfSum[i] = nrOfGuesses;
                    break;
                }
            }
        }

        int sum = Arrays.stream(ArrayOfSum).sum();
        double averageGuesses = (double) sum / ArrayOfSum.length;
        System.out.println("Average number of guesses: " + averageGuesses);
        
    }

    public static HttpResponse<String> sendRequestWithCookie(String url, String cookie) throws Exception {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(url))
                .header("Cookie", cookie)
                .GET()
                .build();
          return client.send(request, HttpResponse.BodyHandlers.ofString());
    }

    public static String extractSetCookie(HttpResponse<String> response ) {
            Map<String, List<String>> headers = response.headers().map();
        List<String> setCookieHeaders = headers.get("Set-Cookie");
        if (setCookieHeaders != null) {
            return setCookieHeaders.stream()
                    .collect(Collectors.joining("; "));
        } else {
            return "";
        }
    }

}
