import java.io.*;
import java.net.*;
import java.util.*;


public class StartUp {
     public static void main(String[] args) {
        int port = 8081;
        Map<String, Game> sessionMap = new HashMap<>();

        try (ServerSocket serverSocket = new ServerSocket(port)) {
             System.out.println("Server is running on port " + port);
             
            while (true) {
                Socket clientSocket = serverSocket.accept();
                Thread thread = new Thread(new Controller(clientSocket, sessionMap));
                thread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
