package server.model;

public enum Role {
    USER,
    ADMIN
}
